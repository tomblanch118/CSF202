public class MallardDuck extends Duck{

	public void display()
	{
		System.out.println("Display: I look like a lovely Mallard Duck");
	}
}
