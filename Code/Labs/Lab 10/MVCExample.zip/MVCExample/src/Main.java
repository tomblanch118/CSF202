/**
 * Model View Controller Example
 * Demonstrates the model view controller design pattern using
 * A bird tally counter (to use while you are bird spotting) as an example.
 * Displays multiple views of the same data.
 */
public class Main {

	public static void main(String[] args) {
		Controller controller = new Controller();
	}
	
}
